README By Tweeks!

You can use The Injector.exe or Fateinjector.exe to run Prax (on fate u must select Prax.dll as Payload)

You Need to install VC_redist.x64.exe otherwise Prax won`t work!
Link : https://aka.ms/vs/17/release/vc_redist.x64.exe

You can choose on of this two versions to play with Prax : 1.20.50 and 1.20.51

with the bedrock launcher you can downgrade ur Minecraft version
Link : https://bedrocklauncher.github.io/

Enjoy!